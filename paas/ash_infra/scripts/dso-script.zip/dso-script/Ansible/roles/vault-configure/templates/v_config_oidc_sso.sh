#!/bin/bash
echo "Vault Name: $1"
echo "Vault Namespace: $2"
echo "oidc_discovery_url: $3"
echo "oidc_client_id: $4"
echo "oidc_client_secret: $5"

oc exec -ti $1 -- vault write -namespace=$2 auth/oidc/config oidc_discovery_url=$3 oidc_client_id=$4 oidc_client_secret=$5 default_role="reader"
