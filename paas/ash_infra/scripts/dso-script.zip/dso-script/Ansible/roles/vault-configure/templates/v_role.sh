#!/bin/bash
echo "Vault Name: $1"
echo "Vault Namespace: $2"

oc exec -ti $1 -- vault write auth/kubernetes/role/pipeline-github bound_service_account_names="pipeline" bound_service_account_namespaces="semir-test" policies=pipeline-github ttl=1m
