#!/bin/bash
echo "Vault Name: $1"
echo "Vault Namespace: $2"

export MY_TOKEN=$(oc exec -ti $1 -- cat /var/run/secrets/kubernetes.io/serviceaccount/token)

export MY_K8S=$(oc exec -ti $1 -- env | grep KUBERNETES_PORT_443_TCP_ADDR | sed -n -e 's/^.*=//p' | tr -d '\n' | tr -d '\r')

export MY_K8S_FQDN=$(echo "https://$MY_K8S:443")

echo $MY_K8S_FQDN

echo $MY_TOKEN

oc exec -ti $1 -- vault write -namespace=$2 auth/kubernetes/config token_reviewer_jwt="$MY_TOKEN" kubernetes_host=$MY_K8S_FQDN kubernetes_ca_cert=@/var/run/secrets/kubernetes.io/serviceaccount/ca.crt issuer=https://kubernetes.default.svc
