#!/bin/bash
echo "Vault Name: $1"
echo "Vault Namespace: $2"

oc exec -ti $1 -- vault policy write -namespace=$2 engineering-admin - << EOF

# Manage namespaces
path "sys/namespaces/*" {
   capabilities = ["create", "read", "update", "delete", "list", "sudo"]
}

path "sys/capabilities"
{
  capabilities = ["create", "update"]
}
path "sys/capabilities-self"
{
  capabilities = ["create", "update"]
}
# Manage policies
path "sys/policies/acl/*" {
   capabilities = ["create", "read", "update", "delete", "list", "sudo"]
}
path "sys/policies/acl" {
   capabilities = ["create", "read", "update", "delete", "list"]
}
path "sys/policies/rgp/*" {
   capabilities = ["create", "read", "update", "delete", "list", "sudo"]
}
path "sys/policies/egp" {
   capabilities = ["create", "read", "update", "delete", "list"]
}
path "sys/policies/egp/*" {
   capabilities = ["create", "read", "update", "delete", "list", "sudo"]
}
path "sys/policies/rgp" {
   capabilities = ["create", "read", "update", "delete", "list"]
}
# Enable and manage secrets engines
path "sys/mounts/*" {
   capabilities = ["create", "read", "update", "delete", "list"]
}

# List available secrets engines
path "sys/mounts" {
  capabilities = [ "create", "read", "list" ]
}
# Create and manage entities and groups
path "identity/*" {
   capabilities = ["create", "read", "update", "delete", "list"]
}
# List, create, update, and delete auth backends
path "sys/auth"
{
  capabilities = ["create", "read", "update", "delete", "list", "sudo"]
}
path "auth/*" {
  capabilities = ["create", "read", "update", "delete", "list", "sudo"]
}

# Manage secrets at 'kv'
# NOTE: Replace/extend this with whatever secret engines are being used in this namespace. 

path "kv/*" {
   capabilities = ["create", "read", "update", "delete", "list"]
}

EOF
