#!/bin/bash
echo "Vault Name: $1"
echo "Vault Namespace: $2"
echo "oidc_client_id: $3"
echo "vault_base_path: $4"

oc exec -ti $1 -- vault write -namespace=$2 auth/oidc/role/reader bound_audiences=$3 allowed_redirect_uris="https://$4/ui/vault/auth/oidc/oidc/callback" user_claim="sub" groups_claim="groups" policies="reader" verbose_oidc_logging="false"
