#!/bin/bash
echo "Vault Name: $1"
echo "Vault Namespace: $2"

# secret
oc exec -ti $1 -- vault kv put -namespace=$2 kv/quay username=dso-project+dso_pipeline_acc password=get-robot-pass

#  role
oc exec -ti $1 -- vault write -namespace=$2 auth/kubernetes/role/pipeline-quay bound_service_account_names="pipeline" bound_service_account_namespaces="semir-test" policies=pipeline-quay ttl=1m

