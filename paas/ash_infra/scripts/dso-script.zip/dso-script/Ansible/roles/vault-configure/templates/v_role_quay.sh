#!/bin/bash
echo "Vault Name: $1"
echo "Vault Namespace: $2"

#  role
oc exec -ti $1 -- vault write -namespace=$2 auth/kubernetes/role/pipeline-quay bound_service_account_names="pipeline" bound_service_account_namespaces="semir-test" policies=pipeline-quay ttl=1m

