#!/bin/bash
echo "OCP Namespace: $1"
echo "Vault Name: $2"
echo "Vault Namespace: $3"


VAULT_AUTH_LIST=$(oc exec -ti -n $1 $2 -- vault auth list -namespace=$3 -format=json)

MOUNT_ACCESSOR=$(echo $VAULT_AUTH_LIST | jq -r '.["oidc/"].accessor' )

VAULT_EXT_GROUP_ENGINEERING_ADMIN=$(kubectl exec -ti -n $1 $2 -- vault write -namespace=$3 -format=json identity/group name="engineering-admin" type="external" policies="engineering-admin")

CANONICAL_ID=$(echo $VAULT_EXT_GROUP_ENGINEERING_ADMIN | jq -r ".data.id")

oc exec -ti -n $1 $2 -- vault write -namespace=$3 -format=json identity/group-alias name="engineering-admin"  mount_accessor=$MOUNT_ACCESSOR canonical_id=$CANONICAL_ID
