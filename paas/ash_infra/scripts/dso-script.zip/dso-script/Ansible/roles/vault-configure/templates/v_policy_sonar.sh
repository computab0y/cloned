#!/bin/bash
echo "Vault Name: $1"
echo "Vault Namespace: $2"

oc exec -ti $1 -- vault policy write -namespace=$2 pipeline-sonar - << EOF

path "kv/data/sonar"
{ capabilities = ["read"]

}
EOF

