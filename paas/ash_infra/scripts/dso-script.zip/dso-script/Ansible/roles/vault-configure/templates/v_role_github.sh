#!/bin/bash
echo "Vault Name: $1"
echo "Vault Namespace: $2"

#  role
oc exec -ti $1 -- vault write -namespace=$2 auth/kubernetes/role/pipeline-github bound_service_account_names="pipeline,default" bound_service_account_namespaces="semir-test,dso-juice-shop" policies=pipeline-github ttl=1m

