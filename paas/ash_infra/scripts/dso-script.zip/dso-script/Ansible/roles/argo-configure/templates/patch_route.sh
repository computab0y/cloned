#!/bin/bash
echo "Argo Namespace: $1"

oc -n $1  patch argocd/$1 --type=merge -p='{"spec":{"server":{"insecure":true,"route":{"enabled":true,"tls":{"insecureEdgeTerminationPolicy":"Redirect","termination":"edge"}}}}}'

