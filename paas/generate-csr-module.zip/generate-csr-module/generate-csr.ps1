# NOTE:**** Need to login to the correct Azure subscription first
# Tool generates CSR using Azure Vault
# execution Format
# powershell ./generate-csr.ps1 Country-Name State Locality Organization-name Organizational-unit AzureSub ValidityInMonths IssuerName VaultName
# powershell ./generate-csr.ps1 GB London London mod IT-Department UKSC-DD-ASDT_PREDA-INFRA_SBOX_001 12 Unknown kv-sbox-shared-e1-uks
	  
$Country=$args[0];
$State=$args[1]; 
$Locality=$args[2]; 
$Org=$args[3]; 
$Orgunit=$args[4];
$AzureSub=$args[5];
$ValidityInMonths=$args[6];
$IssuerName=$args[7];
$VaultName=$args[8];

# SET Azure subscription
echo ============================================================ >> output.log; 
date >> output.log; 
echo "*** Azure Subscription Details ***" >> output.log;
az account set --subscription $AzureSub;
az account show >> output.log; 

# Generate CSRs
echo "*** Generated CSRs List ***" >> output.log;

foreach($line in Get-Content .\input-FQDN.log) {
    if($line -match $regex){		
	  echo "CSR created for ...$line ...ValidityInMonths=$ValidityInMonths ...IssuerName=$IssuerName ...CN = $line, OU = $Orgunit, O = $Org, L = $Locality, S = $State, C = $Country"  >> output.log;
	  
	  # Create a certificate policy
	  #$policy = New-AzKeyVaultCertificatePolicy -SubjectName "CN=$line, OU=$Orgunit, O=$Org, L=$Locality, S=$State, C=$Country" -ValidityInMonths $ValidityInMonths -IssuerName $IssuerName
	$policy = New-AzKeyVaultCertificatePolicy -SubjectName "CN=$line" -ValidityInMonths $ValidityInMonths -IssuerName $IssuerName	  
	  echo "Policy details ..."  >> output.log;
	  echo $policy  >> output.log;

	 # Generate CSR
	 $csrname=$line -replace "\.", "-"	 
	 $csr = Add-AzKeyVaultCertificate -VaultName $VaultName -Name $csrname -CertificatePolicy $policy
	  echo "CSR details ..."  >> output.log;
	  echo $csr  >> output.log;
	  echo "-----BEGIN CERTIFICATE REQUEST-----"  >> output\$csrname".csr";
	  echo $csr.CertificateSigningRequest  >> output\$csrname".csr";
	  echo "-----END CERTIFICATE REQUEST-----"  >> output\$csrname".csr";
    }	
}